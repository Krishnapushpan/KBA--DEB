import React from 'react'
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'

import Home from './pages/Home'
import AddCourse from './pages/AddCourse'
import Contact from './pages/Contact'
import CoursePage from './pages/CoursePage'
import EditCourse from './pages/EditCourse'
import Courses from './pages/Courses'
import NotFound from './pages/NotFound'
const App = () => {
  return (
   <Router>
    <Routes>
    <Route path='/' element={<Home/>}/>
    <Route path='/contact' element={<Contact/>}/>
    <Route path='/editcourse/:id' element={<EditCourse/>}/> 
    <Route path='/addcourse' element={<AddCourse/>}/>
    <Route path='/course/:id' element={<CoursePage/>}/>
    <Route path='/courses' element={<Courses/>}/>
    <Route path='*' element={<NotFound/>}/>
    </Routes >
    </Router>
  )
}

export default App