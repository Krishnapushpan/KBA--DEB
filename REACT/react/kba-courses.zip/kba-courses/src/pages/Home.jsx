import React from 'react'
import Hero from '../components/Hero'
import TopCourses from '../components/TopCourses'
import CourseGrid from '../components/CourseGrid'
import coursesData from '../data/courses.json'
import ViewallCourses from '../components/ViewallCourses'
import MainLayout from '../layouts/MainLayout'

const Home = () => {
  const TopCourse=coursesData.slice(0,3)
  return (

     <MainLayout>
         <Hero/>
         <TopCourses/>
         <ViewallCourses/>
         <CourseGrid courses={TopCourse}/>
         </MainLayout>

  )
}

export default Home